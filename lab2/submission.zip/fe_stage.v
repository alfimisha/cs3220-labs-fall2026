 `include "define.vh" 


module FE_STAGE(
  input wire clk,
  input wire reset,
  input wire [`from_DE_to_FE_WIDTH-1:0] from_DE_to_FE,
  input wire [`from_AGEX_to_FE_WIDTH-1:0] from_AGEX_to_FE,   
  input wire [`from_MEM_to_FE_WIDTH-1:0] from_MEM_to_FE,   
  input wire [`from_WB_to_FE_WIDTH-1:0] from_WB_to_FE, 
  output wire [`FE_latch_WIDTH-1:0] FE_latch_out
);

  `UNUSED_VAR (from_MEM_to_FE)
  `UNUSED_VAR (from_WB_to_FE)

  // I-MEM
  (* ram_init_file = `IDMEMINITFILE *)
  reg [`DBITS-1:0] imem [`IMEMWORDS-1:0];
 
  initial begin
      $readmemh(`IDMEMINITFILE , imem);
  end

  // Display memory contents with verilator 
  /*
  always @(posedge clk) begin
    for (integer i=0 ; i<`IMEMWORDS ; i=i+1) begin
        $display("%h", imem[i]);
    end
  end
  */

  /* pipeline latch */ 
  reg [`FE_latch_WIDTH-1:0] FE_latch;  // FE latch 
  wire valid_FE;
  assign valid_FE = 1'b1;

   
  `UNUSED_VAR(valid_FE)
  reg [`DBITS-1:0] PC_FE_latch; // PC latch in the FE stage   // you could use a part of FE_latch as a PC latch as well 
  
  reg [`DBITS-1:0] inst_count_FE; /* for debugging purpose */ 
  
  wire [`DBITS-1:0] inst_count_AGEX; /* for debugging purpose. resent the instruction counter */ 

  wire [`INSTBITS-1:0] inst_FE;  // instruction value in the FE stage 
  wire [`DBITS-1:0] pcplus_FE;  // pc plus value in the FE stage 
  wire stall_pipe_FE; // signal to indicate when a front-end needs to be stall

  // TODO Task 3: connect BHR and PHT to the pipeline.
  wire [`BHR_WIDTH-1:0] bhr_FE;
  wire [`PHT_BITS-1:0] pht_index_FE;
  wire pht_prediction_FE;

  wire update_predictor_AGEX;
  wire branch_result_AGEX;
  wire [`PHT_BITS-1:0] pht_index_AGEX;

  // Task 5: BTB lookup and next-PC prediction
  wire btb_hit_FE;
  wire [`DBITS-1:0] btb_target_FE;
  wire [`DBITS-1:0] pred_next_pc_FE;

  wire [`DBITS-1:0] btb_wr_pc_AGEX;
  wire [`DBITS-1:0] btb_wr_target_AGEX;

  // G-share
  assign pht_index_FE = PC_FE_latch[9:2] ^ bhr_FE;

  BHR bhr (
      .clk(clk),
      .reset(reset),
      .wr_ena(update_predictor_AGEX),
      .wr_data({31'b0, branch_result_AGEX}),
      .out(bhr_FE)
  );

  PHT pht (
      .clk(clk),
      .reset(reset),

      .rd_sel(pht_index_FE),
      .out(pht_prediction_FE),

      .wr_sel(pht_index_AGEX),
      .wr_data(branch_result_AGEX),
      .wr_ena(update_predictor_AGEX)
  );

  BTB btb (
      .clk(clk),
      .reset(reset),
      .rd_ena(1'b1),
      .rd_sel(PC_FE_latch),
      .out_data(btb_target_FE),
      .outs_valid(btb_hit_FE),
      .wr_ena(update_predictor_AGEX),
      .wr_sel(btb_wr_pc_AGEX),
      .wr_data(btb_wr_target_AGEX)
  );

  // Predict taken only when the BTB knows the target and the PHT says taken
  assign pred_next_pc_FE = (btb_hit_FE && pht_prediction_FE) ? btb_target_FE : pcplus_FE;
  

  
  wire [`FE_latch_WIDTH-1:0] FE_latch_contents;  // the signals that will be FE latch contents 
  
  // reading instruction from imem 
  assign inst_FE = imem[PC_FE_latch[`IMEMADDRBITS-1:`IMEMWORDBITS]];  // this code works. imem is stored 4B together 
  
  // wire to send the FE latch contents to the DE stage 
  assign FE_latch_out = FE_latch; 
 

  // This is the value of "incremented PC", computed in the FE stage
  assign pcplus_FE = PC_FE_latch + `INSTSIZE;
   
   // the order of latch contents should be matched in the decode stage when we extract the contents. 
  assign FE_latch_contents = {
                                valid_FE, 
                                inst_FE, 
                                PC_FE_latch, 
                                pcplus_FE, // please feel free to add more signals such as valid bits etc. 
                                inst_count_FE,
                                // if you add more bits here, please increase the width of latch in VX_define.vh 
                                pht_index_FE,
                                pht_prediction_FE,
                                pred_next_pc_FE
                                };
                            




  // **TODO: Complete the rest of the pipeline 
  //assign stall_pipe_FE = 1;   // you need
  wire br_mispred_AGEX;  
  wire [`DBITS-1:0] br_target_AGEX;  

  assign {
    stall_pipe_FE
  } = from_DE_to_FE[0]; 

  assign {
    br_mispred_AGEX,
    br_target_AGEX,
    update_predictor_AGEX,
    branch_result_AGEX,
    pht_index_AGEX,
    btb_wr_pc_AGEX,
    btb_wr_target_AGEX
  } = from_AGEX_to_FE;

  always @ (posedge clk) begin
  // Task 5: select the predicted next PC.
   if (reset) begin 
      PC_FE_latch <= `STARTPC;
      inst_count_FE <= 1;  /* inst_count starts from 1 for easy human reading. 1st fetch instructions can have 1 */ 
      end 
    else if (br_mispred_AGEX)
      PC_FE_latch <= br_target_AGEX;
    else if (stall_pipe_FE) 
      PC_FE_latch <= PC_FE_latch; 
    else begin 
      PC_FE_latch <= pred_next_pc_FE;
      inst_count_FE <= inst_count_FE + 1; 
      end 
  end
  

  always @ (posedge clk) begin
    if (reset) begin 
      FE_latch <= '0; 
    end else begin 
      if (br_mispred_AGEX)
        FE_latch <= '0;
      else if (stall_pipe_FE)
        FE_latch <= FE_latch; 
      else 
        FE_latch <= FE_latch_contents; 
    end  
  end



endmodule

// Task 1: Branch history pattern logic
module BHR (
  input wire clk,
  input wire reset,
  input wire wr_ena,               
  input wire [`DBITS-1:0] wr_data,   
  output reg [`BHR_WIDTH-1:0] out    
);

always @(posedge clk) begin
  if (reset) begin
    out <= {`BHR_WIDTH{1'b0}};
  end else if (wr_ena) begin 
    out <= {out[`BHR_WIDTH-2:0], wr_data[0]}; 
  end
end

endmodule

// Task 2: Prediction History table register pattern
//You should define the counter in each PHT pattern
module PHT (
  input wire clk,
  input wire reset,
  input wire [`PHT_BITS-1:0] rd_sel,
  output wire out,                     
  input wire [`PHT_BITS-1:0] wr_sel,
  input wire wr_data,
  input wire wr_ena
);

integer i;
reg [1:0] PHT [0:(1 << `PHT_BITS)-1];

always @(posedge clk) begin
  if (reset) begin
    for (i = 0; i < (1 << `PHT_BITS); i = i + 1) begin
      PHT[i] <= 2'b01; 
    end
  end else if (wr_ena) begin
    if (wr_data == 1'b1) begin
      if (PHT[wr_sel] != 2'b11) begin
        PHT[wr_sel] <= PHT[wr_sel] + 1'b1; 
      end
    end else begin
      if (PHT[wr_sel] != 2'b00) begin
        PHT[wr_sel] <= PHT[wr_sel] - 1'b1; 
      end
    end
  end
end


assign out = PHT[rd_sel][1];

endmodule
// Task 4: Branch Target Buffer
//Hint: what is the signal need for BHT update?

module BTB (
  input wire clk,
  input wire reset,
  input wire rd_ena,
  input wire [`DBITS-1:0] rd_sel,
  output wire [`DBITS-1:0] out_data,
  output wire outs_valid,
  input wire wr_ena,
  input wire [`DBITS-1:0] wr_sel,
  input wire [`DBITS-1:0] wr_data
); 

  reg              btb_valid  [0:15];
  reg [25:0]       btb_tag    [0:15];   // PC[31:6]
  reg [`DBITS-1:0] btb_target [0:15];

  integer i;

  wire [3:0]  rd_idx = rd_sel[5:2];
  wire [25:0] rd_tag = rd_sel[31:6];

  assign outs_valid = rd_ena && btb_valid[rd_idx] && (btb_tag[rd_idx] == rd_tag);
  assign out_data   = btb_target[rd_idx];

  wire [3:0]  wr_idx = wr_sel[5:2];

  always @(posedge clk) begin
    if (reset) begin
      for (i = 0; i < 16; i = i + 1)
        btb_valid[i] <= 1'b0;
    end else if (wr_ena) begin
      btb_valid[wr_idx]  <= 1'b1;
      btb_tag[wr_idx]    <= wr_sel[31:6];
      btb_target[wr_idx] <= wr_data;
    end
  end

endmodule
